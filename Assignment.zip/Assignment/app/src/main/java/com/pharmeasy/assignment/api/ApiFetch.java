package com.pharmeasy.assignment.api;


import com.pharmeasy.assignment.model.Fullresults;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;

public interface ApiFetch
{

   // https://22966f1d-9859-4044-a923-ec55f168660e.mock.pstmn.io/api/Retailers/4990224/fetchFrequentlyOrderedProduct?retailerId=4990224/VGhlcmUncyBhIGxhZHkgd2hvJ3Mgc3VyZQ0KQWxsIHRoYXQgZ2xpdHRlcnMgaXMgZ29sZA
   // @GET("VGhlcmUncyBhIGxhZHkgd2hvJ3Mgc3VyZQ0KQWxsIHRoYXQgZ2xpdHRlcnMgaXMgZ29sZA")
    @GET("Retailers/4990224/fetchFrequentlyOrderedProduct?retailerId=4990224/VGhlcmUncyBhIGxhZHkgd2hvJ3Mgc3VyZQ0KQWxsIHRoYXQgZ2xpdHRlcnMgaXMgZ29sZA")
    Call<List<Fullresults>> getresults();

}
