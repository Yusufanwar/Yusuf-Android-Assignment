package com.pharmeasy.assignment.model;


import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class Fullresults {

    @Expose
    @SerializedName("productName")
    private  String productName;

    @Expose
    @SerializedName("displayText")
    private  String displayText;

    @Expose
    @SerializedName("schemeLabelForRetailer")
    private  String schemeLabelForRetailer;

    @Expose
    @SerializedName("distributorName")
    private  String distributorName;

    @Expose
    @SerializedName("manufacturerName")
    private  String manufacturerName;

    @Expose
    @SerializedName("mrp")
    private  double mrp;

    @Expose
    @SerializedName("ptr")
    private  double ptr;

    @Expose
    @SerializedName("stock")
    private  int stock;

    @Expose
    @SerializedName("productUrl")
    private  String productUrl;

    @Expose
    @SerializedName("smartRecommendation")
    private  boolean smartRecommendation;


    public Fullresults(String productName, String displayText, String schemeLabelForRetailer, String distributorName, String manufacturerName, double mrp, double ptr, int stock, String productUrl, boolean smartRecommendation) {
        this.productName = productName;
        this.displayText = displayText;
        this.schemeLabelForRetailer = schemeLabelForRetailer;
        this.distributorName = distributorName;
        this.manufacturerName = manufacturerName;
        this.mrp = mrp;
        this.ptr = ptr;
        this.stock = stock;
        this.productUrl = productUrl;
        this.smartRecommendation = smartRecommendation;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getDisplayText() {
        return displayText;
    }

    public void setDisplayText(String displayText) {
        this.displayText = displayText;
    }

    public String getSchemeLabelForRetailer() {
        return schemeLabelForRetailer;
    }

    public void setSchemeLabelForRetailer(String schemeLabelForRetailer) {
        this.schemeLabelForRetailer = schemeLabelForRetailer;
    }

    public String getDistributorName() {
        return distributorName;
    }

    public void setDistributorName(String distributorName) {
        this.distributorName = distributorName;
    }

    public String getManufacturerName() {
        return manufacturerName;
    }

    public void setManufacturerName(String manufacturerName) {
        this.manufacturerName = manufacturerName;
    }

    public double getMrp() {
        return mrp;
    }

    public void setMrp(double mrp) {
        this.mrp = mrp;
    }

    public double getPtr() {
        return ptr;
    }

    public void setPtr(double ptr) {
        this.ptr = ptr;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public String getProductUrl() {
        return productUrl;
    }

    public void setProductUrl(String productUrl) {
        this.productUrl = productUrl;
    }

    public boolean isSmartRecommendation() {
        return smartRecommendation;
    }

    public void setSmartRecommendation(boolean smartRecommendation) {
        this.smartRecommendation = smartRecommendation;
    }
}
