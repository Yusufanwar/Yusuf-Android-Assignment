package com.pharmeasy.assignment.model;

import okhttp3.OkHttpClient;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class ApiResponce {

    public  static final String
            BaseUrl="https://22966f1d-9859-4044-a923-ec55f168660e.mock.pstmn.io/api/";
    private static Retrofit retrofit=null;

    public  static Retrofit getRetrofit()
    {
        OkHttpClient.Builder client= new OkHttpClient.Builder();

        Retrofit.Builder builder=new Retrofit.Builder()
                .baseUrl(BaseUrl)
                .addConverterFactory(GsonConverterFactory.create());

        retrofit=builder.client(client.build())
                .build();


        return  retrofit;

    }





}
