package com.pharmeasy.assignment.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TableLayout;
import android.widget.Toast;

import com.google.android.material.tabs.TabLayout;
import com.pharmeasy.assignment.R;
import com.pharmeasy.assignment.activity.fragments.Frequent;
import com.pharmeasy.assignment.activity.fragments.Recommended;
import com.pharmeasy.assignment.api.ApiFetch;
import com.pharmeasy.assignment.model.ApiResponce;
import com.pharmeasy.assignment.model.Fullresults;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    TabLayout tabs;
    ViewPager viewPager;
    ViewPagerAdapter adapter;
    public  static  List<Fullresults> fullresults;
    ProgressDialog progressDialog;

    private int  count=0;
    public  static ArrayList<Integer> trueCountArray=new ArrayList<>();
    public  static ArrayList<Integer> falseCountArrayList=new ArrayList<>();

    private  static ApiFetch apiInter= ApiResponce.getRetrofit().create(ApiFetch.class);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_main);
        responseGet();
        tabs =  findViewById(R.id.tabs1);
        viewPager=findViewById(R.id.viewpager1);
    }
    public void responseGet()
    {
        progressDialog = ProgressDialog.show(MainActivity.this, "Please Wait", "Loading Medicines...");
        Call<List<Fullresults>> call=apiInter.getresults();
        call.enqueue(new Callback<List<Fullresults>>() {
            @Override
            public void onResponse(Call<List<Fullresults>> call, Response<List<Fullresults>> response) {
              //  Toast.makeText(MainActivity.this, "Connection successfull", Toast.LENGTH_SHORT).show();
                System.out.println("@@@@@@@@@@@@@@@@@@@@ @ @ @ @ resukt"+response);
                fullresults=response.body();

                for (Fullresults pharmresltss:fullresults)
                {
                    System.out.println("@@@@@@@@@@@@@@@@@@@@ @ @ @ @ pro"+pharmresltss.getProductName());
                    if(pharmresltss.isSmartRecommendation())
                    {
                        trueCountArray.add(count);
                        count++;

                    }else {
                        falseCountArrayList.add(count);
                        count++;

                    }
                }
                addTabs(viewPager);
                tabs.setupWithViewPager(viewPager);
                progressDialog.dismiss();

            }

            @Override
            public void onFailure(Call<List<Fullresults>> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(MainActivity.this, "Connection not successfull", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private  void addTabs(ViewPager viewPager)
    {
        adapter = new ViewPagerAdapter(getSupportFragmentManager());
        adapter.addFrag(new Frequent(),"Frequently Ordered");
        adapter.addFrag(new Recommended(), "Recommended");
        viewPager.setAdapter(adapter);
    }
    class ViewPagerAdapter extends FragmentPagerAdapter
    {
        private final List mFragmentList = new ArrayList<>();
        private final List mFragmentTitleList = new ArrayList<>();

        public ViewPagerAdapter(FragmentManager manager){

            super(manager);

        }

        @Override
        public Fragment getItem(int position)
        {
            return (Fragment) mFragmentList.get(position);
        }

        @Override
        public int getCount() {
            return mFragmentList.size();
        }

        public void addFrag(Fragment fragment, String title) {
            mFragmentList.add(fragment);
            mFragmentTitleList.add(title);
        }

        @Override
        public CharSequence getPageTitle(int position) {
            return (CharSequence) mFragmentTitleList.get(position);
        }
    }
}