package com.pharmeasy.assignment.adapter;

import android.content.Context;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.pharmeasy.assignment.R;
import com.pharmeasy.assignment.model.Fullresults;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

public class CustomAdapter1 extends RecyclerView.Adapter<CustomAdapter1.MyViewHolderGallery> {
        int  width, height;
        ArrayList<Integer> valuesort=new ArrayList<>();
        Context context;
        List<Fullresults> fullresults=new ArrayList<>();
        Boolean value;

        public CustomAdapter1(Context context,List<Fullresults> fullresults,ArrayList<Integer> valuesort,Boolean value) {
            this.context = context;
            this.fullresults=fullresults;
            this.valuesort=valuesort;
            this.value=value;
            System.out.println("################    pfff"+fullresults.size()+" object "+fullresults);
            DisplayMetrics metrics = context.getResources().getDisplayMetrics();
            width = metrics.widthPixels;
            height = metrics.heightPixels;
        }

        @Override
        public MyViewHolderGallery onCreateViewHolder(ViewGroup parent, int viewType) {
           View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.framegridobjectportrait, parent, false);
            MyViewHolderGallery vh = new  MyViewHolderGallery(v);
            return vh;
        }

        @Override
        public void onBindViewHolder(MyViewHolderGallery holder, final int position) {

            Fullresults pharmeasyresults=fullresults.get(valuesort.get(position));
            if (value.equals(pharmeasyresults.isSmartRecommendation()))
            {
                System.out.println("!!!!!!!!!!!!!!!!!!!  !!pro   dud"+pharmeasyresults.getProductName());
                holder.productname.setText(""+pharmeasyresults.getProductName());
                holder.distributor.setText(""+pharmeasyresults.getDistributorName());
                holder.stock.setText(""+"Qty "+pharmeasyresults.getStock());
                holder.displaytext.setText(""+pharmeasyresults.getDisplayText());
                holder.scheme.setText(""+pharmeasyresults.getSchemeLabelForRetailer());
                holder.manufacture.setText(""+pharmeasyresults.getManufacturerName());
                holder.mrp.setText(""+"\u20B9"+pharmeasyresults.getMrp());
                holder.ptr.setText(""+"\u20B9"+pharmeasyresults.getPtr());
                Picasso.with(context)
                        .load(pharmeasyresults.getProductUrl())
                        .into(holder.image);
            }

        }

        @Override
        public int getItemCount() {

            return valuesort.size();
        }

        public class MyViewHolderGallery extends RecyclerView.ViewHolder {
            TextView productname,displaytext,scheme,distributor,manufacture,mrp,ptr,stock;
            ImageView image;

            //ArrayList<Integer> imgs=new ArrayList<>(Arrays.asList(R.id.sample1,R.id.sample2,R.id.sample3,R.id.sample4,R.id.sample5,R.id.sample6));

            public MyViewHolderGallery(View itemView) {
                super(itemView);
                productname=itemView.findViewById(R.id.products);
                image=itemView.findViewById(R.id.imgpro);
                displaytext=itemView.findViewById(R.id.displaytext);
                scheme=itemView.findViewById(R.id.schemelabel);
                distributor=itemView.findViewById(R.id.distibustor);
                manufacture=itemView.findViewById(R.id.manufacturename);
                mrp=itemView.findViewById(R.id.mrp);
                ptr=itemView.findViewById(R.id.ptr);
                stock=itemView.findViewById(R.id.stock);
               // img = itemView.findViewById(R.id.galleryImageView);
                // img.setPadding(0,20,0,0);
            }
        }
    }
